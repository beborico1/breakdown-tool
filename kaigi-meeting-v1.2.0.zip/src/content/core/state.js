// Global state for translation tracking

// Track the last copied index for "Copy New" feature
export let lastCopiedIndex = 0;
export function setLastCopiedIndex(value) {
  lastCopiedIndex = value;
}

// Minimalistic mode state
export let minimalisticModeEnabled = false;
export function setMinimalisticModeEnabled(value) {
  minimalisticModeEnabled = value;
}

// Translation state keyed by container element
// Value: { originalText, originalEl, translatedText, translatedEl, contentKey,
//          lastTranslatedLength, shadowOriginalEl, speakerName, isIncremental,
//          breakdownData, isExpanded,
//          // Minimalistic mode specific:
//          minimalisticState: { processedUpTo, processingUpTo, wordBoundaries, sentenceRanges, processTimer } }
export const translationState = new Map();

// Delta translation debouncing
export const DELTA_DEBOUNCE_MS = 500;

// Sentence-level processing debounce (wait for speech recognition to settle)
export const SENTENCE_DEBOUNCE_MS = 400;
export const pendingDeltas = new Map();

// Cache translations by content key (survives container replacement)
// Key: `${speaker}|${textHash}|${timeBucket}`
// Value: { translatedText, breakdownData, timestamp, speaker, originalText }
export const translationCache = new Map();

// Text-only breakdown cache (keyed by hashText(text), no time bucket)
// Ensures identical text always produces the same tokenization on re-processing
// Value: { breakdownData, timestamp }
export const breakdownCache = new Map();

// Track which content keys are currently displayed (user hasn't toggled off)
export const activeContentKeys = new Set();

// Cache pruning interval (5 minutes)
export const CACHE_MAX_AGE_MS = 5 * 60 * 1000;

// Word frequency tracking
export const FREQUENCY_SAVE_DEBOUNCE_MS = 2000;
export let frequencySaveTimeout = null;
export function setFrequencySaveTimeout(value) {
  frequencySaveTimeout = value;
}
export const pendingFrequencyUpdates = new Map(); // Accumulate updates before saving
export const countedContentKeys = new Set(); // Track which translations have been counted

// Observer loop detection
export let observerCallCount = 0;
export let observerCallWindowStart = Date.now();
export const OBSERVER_RATE_LIMIT = 50; // max calls per second before warning

export function incrementObserverCallCount() {
  observerCallCount++;
}

export function resetObserverCallCount() {
  observerCallCount = 0;
  observerCallWindowStart = Date.now();
}

export function getObserverCallCount() {
  return observerCallCount;
}

export function getObserverCallWindowStart() {
  return observerCallWindowStart;
}

// API call counter
export let apiCallCount = 0;
export function incrementApiCallCount() {
  return ++apiCallCount;
}

// Observer config (reusable for observe/reconnect)
export const OBSERVER_CONFIG = {
  childList: true,
  subtree: true,
  characterData: true,
};

// Word block font size
export let wordBlockFontSize = 15;
export function setWordBlockFontSize(value) { wordBlockFontSize = value; }

// Sentence chunk size (process every N sentence-ending marks)
export let sentenceChunkSize = 2;
export function setSentenceChunkSize(value) { sentenceChunkSize = value; }

// Google Chat state
export let activeGcwbOverlay = null;
export let activeGcwbContextMenu = null;
export let overlayCreatedAt = 0;

export function setActiveGcwbOverlay(value) {
  activeGcwbOverlay = value;
}

export function setActiveGcwbContextMenu(value) {
  activeGcwbContextMenu = value;
}

export function setOverlayCreatedAt(value) {
  overlayCreatedAt = value;
}

// Track inline breakdown state per message element
// Value: { originalHTML, breakdownData, isShowingBreakdown, loadingIndicator }
export const inlineBreakdownState = new Map();

// Session-long transcript accumulator for auto-download on meeting end.
// Entries live in insertion order (order captions first appeared).
// Each entry: { speaker, text, firstSeen }
export const sessionTranscript = [];

// Maps a caption container element to its index in sessionTranscript,
// so later text updates mutate the same entry instead of appending a new one.
export const containerToTranscriptIndex = new WeakMap();

export function resetSessionTranscript() {
  sessionTranscript.length = 0;
  // WeakMap entries are released as their container elements are GC'd.
}
